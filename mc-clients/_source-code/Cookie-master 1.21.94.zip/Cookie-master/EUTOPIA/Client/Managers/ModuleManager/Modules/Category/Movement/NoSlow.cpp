#include "NoSlow.h"

NoSlow::NoSlow() : Module("NoSlow", "Don't get slowed down when eating/using item", Category::MOVEMENT) {
}