#include "NoPacket.h"

NoPacket::NoPacket() : Module("NoPacket", "Stop sending packets to servers\n(This module commonly used for bug/dupe on server)", Category::MISC) {
}