#pragma once
#include "../../ModuleBase/Module.h"

class NoSlow : public Module {
public:
	NoSlow();
};
#pragma once
