#include "NoSwing.h"

NoSwing::NoSwing() : Module("NoSwing", "Disable arm swing animation", Category::RENDER) {
}