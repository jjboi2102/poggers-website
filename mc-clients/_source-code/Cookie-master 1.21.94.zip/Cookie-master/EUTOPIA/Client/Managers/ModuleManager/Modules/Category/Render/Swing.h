#pragma once
#include "../../ModuleBase/Module.h"

class Swing : public Module {
public:
	int swingSpeed = 12;

	Swing();
};
