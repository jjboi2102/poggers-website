#pragma once
#include "DrawUtils.h"

class GuiUtils {
public:
	static void drawCrossLine(Vec2 pos, MC_Color col, float lineWidth, float crossSize, bool secondCross);
};
