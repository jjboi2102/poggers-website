#pragma once

class Player;

struct LevelEvent {
    Player* mPlayer;
};