#pragma once

#include "Cancellable.h"

struct RenderEvent {
    ImGuiIO& io;
    float fps;
};