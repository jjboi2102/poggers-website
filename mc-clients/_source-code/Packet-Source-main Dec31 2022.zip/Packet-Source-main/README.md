<p align="center">
	<img width="755" height="175" src="assets/images/logo.png">
</p>

# Info
Packet Client is an MCBE Utility mod made by: Packet and Deq
Packet Client is a fork of the Horion Client


## Credits

The original Horion developers

Turakan - Original TargetHUD & LowHop

12brendon34 - Injector

Founder - Very cool dood
