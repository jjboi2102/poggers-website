#include "Speed.h"
Speed::Speed() : IModule(0, Category::MOVEMENT, "sped lol") {
	registerEnumSetting("Mode", &mode, 0);
	mode.addEntry("Vanilla", 0);
	mode.addEntry("Hive", 1);
	mode.addEntry("HiveLow", 3);
	//mode.addEntry("Inviscow", 4); // doesnt work lol
	registerIntSetting("Timer", &timer, timer, 20, 60);
	registerFloatSetting("Height", &height, height, 0.000001f, 0.40f);
	registerFloatSetting("Speed", &speed, speed, 0.2f, 2.f);
}

Speed::~Speed() {
}

const char* Speed::getRawModuleName() {
	return "Speed";
}

const char* Speed::getModuleName() {
	if (mode.getSelectedValue() == 0) {  // Vanilla
		name = std::string("Speed ") + std::string(GRAY) + std::string("Vanilla");
		return name.c_str();
	}
	if (mode.getSelectedValue() == 1) {  // Hive
		name = std::string("Speed ") + std::string(GRAY) + std::string("Hive");
		return name.c_str();
	}
	if (mode.getSelectedValue() == 3) {  // HiveLow
		name = std::string("Speed ") + std::string(GRAY) + std::string("HiveLow");
		return name.c_str();
	}
	if (mode.getSelectedValue() == 4) {  // Inviscow
		name = std::string("Speed ") + std::string(GRAY) + std::string("Inviscow");
		return name.c_str();
	}
}

void Speed::onEnable() {
	if (mode.getSelectedValue() == 1) {
		hiveC = 0;
		hiveC2 = 0;
		lhtick = 0;
	}
}

void Speed::onTick(C_GameMode* gm) {
	if (g_Data.getLocalPlayer() == nullptr)
		return;

	C_GameSettingsInput* input = g_Data.getClientInstance()->getGameSettingsInput();
	*g_Data.getClientInstance()->minecraft->timer = static_cast<float>(timer);
	if (mode.getSelectedValue() == 1) {
		if (gm->player->onGround) {
			lhtick++;
			if (lhtick >= 3)
				lhtick = 0;
			if (g_Data.getLocalPlayer()->velocity.squaredxzlen() >= 0.200 && lhtick == 0) {
				gm->player->velocity.x *= .387f;
				gm->player->velocity.z *= .387f;
			} else if (g_Data.getLocalPlayer()->velocity.squaredxzlen() <= 0.1 && lhtick == 0)
				return;
		}
	}
	if (mode.getSelectedValue() == 1) {
		if (!gm->player->onGround) {
			hiveC++;
			hiveC2++;
		}

		std::vector<vec3_ti> sideBlocks;
		sideBlocks.reserve(8);

		float calcYaw = (gm->player->yaw + 90) * (PI / 180);
		vec3_t moveVec;
		float c = cos(calcYaw);
		float s = sin(calcYaw);

		for (int x = -1; x <= 1; x++) {
			for (int z = -1; z <= 1; z++) {
				if (x == 0 && z == 0)
					continue;

				sideBlocks.push_back(vec3_ti(x, 0, z));
			}
		}

		auto pPos = *gm->player->getPos();
		pPos.y = gm->player->aabb.lower.y;
		auto pPosI = vec3_ti(pPos.floor());

		auto isObstructed = [&](int yOff, AABB* obstructingBlock = nullptr, bool ignoreYcoll = false) {
			for (const auto& current : sideBlocks) {
				vec3_ti side = pPosI.add(0, yOff, 0).add(current);
				if (side.y < 0 || side.y >= 256)
					break;
				auto block = gm->player->region->getBlock(side);
				if (block == nullptr || block->blockLegacy == nullptr)
					continue;
				C_BlockLegacy* blockLegacy = block->toLegacy();
				if (blockLegacy == nullptr)
					continue;
				AABB collisionVec;
				if (!blockLegacy->getCollisionShape(&collisionVec, block, gm->player->region, &side, gm->player))
					continue;
				bool intersects = ignoreYcoll ? collisionVec.intersectsXZ(gm->player->aabb.expandedXZ(0.3f)) : collisionVec.intersects(gm->player->aabb.expandedXZ(0.3f));

				if (intersects) {
					if (obstructingBlock != nullptr)
						*obstructingBlock = collisionVec;
					return true;
				}
			}
			return false;
		};

		AABB lowerObsVec, upperObsVec;
		bool upperObstructed = isObstructed(1, &upperObsVec);

		bool lowerObstructed = isObstructed(0, &lowerObsVec);
		if (lowerObstructed || upperObstructed) intersect = true;
		else intersect = false;

		auto player = g_Data.getLocalPlayer();
		float yaw = player->yaw;
		if (input->spaceBarKey) {
			if (input->forwardKey && input->backKey && input->rightKey && input->leftKey) {
			}
		}
	}
}

void Speed::onMove(C_MoveInputHandler* input) {
	auto targetStrafe = moduleMgr->getModule<TargetStrafe>();
	if (g_Data.getLocalPlayer() == nullptr)
		return;

	vec2_t moveVec2d = {input->forwardMovement, -input->sideMovement};
	bool pressed = moveVec2d.magnitude() > 0.f;
	auto player = g_Data.getLocalPlayer();

	if (mode.getSelectedValue() == 0) {  // Vanilla
		static bool velocity = false;
		if (height >= 0.385) {
			if (player->onGround && pressed) player->jumpFromGround();
			velocity = false;
		} else {
			velocity = true;
		}
		if (height <= 0.04 && !input->isJumping) {
			player->velocity.y += height;
			velocity = false;
		}

		if (player->onGround && pressed && !input->isJumping && velocity)
			player->velocity.y = height;
		float calcYaw = (player->yaw + 90) * (PI / 180);
		vec3_t moveVec;
		float c = cos(calcYaw);
		float s = sin(calcYaw);
		moveVec2d = {moveVec2d.x * c - moveVec2d.y * s, moveVec2d.x * s + moveVec2d.y * c};
		moveVec.x = moveVec2d.x * speed;
		moveVec.y = player->velocity.y;
		moveVec.z = moveVec2d.y * speed;
		if (targetStrafe->isEnabled() && targetStrafe->mode.getSelectedValue() == 1 && !targetStrafe->targetListEmpty)
			return;
		if (!pressed && player->damageTime == 0) {
			player->velocity.x *= 0;
			player->velocity.z *= 0;
		}
		if (pressed) player->lerpMotion(moveVec);
	}
	if (mode.getSelectedValue() == 1) {  // HIV-e aids
		if (pressed) {
			player->setSprinting(true);
			if (player->onGround) {
				player->jumpFromGround();
			}
		}

		float calcYaw = (player->yaw + 90) * (PI / 180);
		vec3_t moveVec;
		float c = cos(calcYaw);
		float s = sin(calcYaw);
		moveVec2d = {moveVec2d.x * c - moveVec2d.y * s, moveVec2d.x * s + moveVec2d.y * c};

		if (pressed) {
			if (player->onGround) speedIndexThingyForHive = 0;
			float currentSpeed = epicHiveSpeedArrayThingy[speedIndexThingyForHive];
			moveVec.x = moveVec2d.x * currentSpeed;
			moveVec.y = player->velocity.y;
			moveVec.z = moveVec2d.y * currentSpeed;
			player->lerpMotion(moveVec);
			if (speedIndexThingyForHive < 30) speedIndexThingyForHive++;
		}
	}
	if (mode.getSelectedValue() == 3 && g_Data.isInGame()) {
		if (player == nullptr) return;

		vec2_t moveVec2d = {input->forwardMovement, -input->sideMovement};
		bool pressed = moveVec2d.magnitude() > 0.01f;

		if (player->onGround && pressed && groundTimer >= 2) {
			player->jumpFromGround();
			player->velocity.y = -0.1f;
			player->velocity.y = 0.23;
			groundTimer = 0;
		}

		if (player->onGround) {
			player->fallDistance = 0;
			preventKick = false;
			groundTimer++;
		}

		float calcYaw = (player->yaw + 90) * (PI / 180);
		float calcYaw2 = (player->yaw - 90) * (PI / 180);
		vec3_t moveVec;
		float c = cos(calcYaw);
		float s = sin(calcYaw);
		float c2 = cos(calcYaw2);
		float s2 = sin(calcYaw2);
		moveVec2d = {moveVec2d.x * c - moveVec2d.y * s, moveVec2d.x * s + moveVec2d.y * c};
		moveVec.x = moveVec2d.x * speed;
		moveVec.y = player->velocity.y;
		moveVec.z = moveVec2d.y * speed;

		if (pressed) player->lerpMotion(moveVec);
		if (g_Data.getLocalPlayer()->velocity.squaredxzlen() > 0.01) {
			C_MovePlayerPacket p = C_MovePlayerPacket(g_Data.getLocalPlayer(), player->getPos()->add(vec3_t(c2 * .1f, 0.f, s2 * .1f)));
			g_Data.getClientInstance()->loopbackPacketSender->sendToServer(&p);
			C_MovePlayerPacket p2 = C_MovePlayerPacket(g_Data.getLocalPlayer(), player->getPos()->add(vec3_t(player->velocity.x / 1.3f, 0.f, player->velocity.z / 2.3f)));
			g_Data.getClientInstance()->loopbackPacketSender->sendToServer(&p2);
		}

		if (player->fallDistance >= 2 && !preventKick) {
			player->fallDistance = 0;
			preventKick = true;
			moduleMgr->getModule<Speed>()->setEnabled(false);
			auto boxWarn = g_Data.addInfoBox("Speed:", "Disabled to prevent kick");
			boxWarn->closeTimer = 7;
		}
	}
}

void Speed::onDisable() {
	auto scaffold = moduleMgr->getModule<Scaffold>();
	auto player = g_Data.getLocalPlayer();
	*g_Data.getClientInstance()->minecraft->timer = 20.f;
	if (!player->onGround && mode.getSelectedValue() != 3) {
		player->velocity.x = 0.f;
		player->velocity.z = 0.f;
	}
	preventKick = false;
}

void Speed::onSendPacket(C_Packet* packet) {
	auto player = g_Data.getLocalPlayer();
	if (mode.getSelectedValue() == 1 || mode.getSelectedValue() == 2) {
		auto killaura = moduleMgr->getModule<Killaura>();
		//auto scaffold = moduleMgr->getModule<Scaffold>();
		if (packet->isInstanceOf<C_MovePlayerPacket>() && g_Data.getLocalPlayer() != nullptr && g_Data.isInGame() && !killaura->isEnabled()) {
			auto* movePacket = reinterpret_cast<C_MovePlayerPacket*>(packet);
			C_GameSettingsInput* input = g_Data.getClientInstance()->getGameSettingsInput();
			if (input == nullptr)
				return;

			float yaw = player->yaw;

			if (GameData::isKeyDown(*input->forwardKey) && GameData::isKeyDown(*input->backKey))
				return;
			else if (GameData::isKeyDown(*input->forwardKey) && GameData::isKeyDown(*input->rightKey) && !GameData::isKeyDown(*input->leftKey)) {
				yaw += 45.f;
			} else if (GameData::isKeyDown(*input->forwardKey) && GameData::isKeyDown(*input->leftKey) && !GameData::isKeyDown(*input->rightKey)) {
				yaw -= 45.f;
			} else if (GameData::isKeyDown(*input->backKey) && GameData::isKeyDown(*input->rightKey) && !GameData::isKeyDown(*input->leftKey)) {
				yaw += 135.f;
			} else if (GameData::isKeyDown(*input->backKey) && GameData::isKeyDown(*input->leftKey) && !GameData::isKeyDown(*input->rightKey)) {
				yaw -= 135.f;
			} else if (GameData::isKeyDown(*input->forwardKey)) {
			} else if (GameData::isKeyDown(*input->backKey)) {
				yaw += 180.f;
			} else if (GameData::isKeyDown(*input->rightKey) && !GameData::isKeyDown(*input->leftKey)) {
				yaw += 90.f;
			} else if (GameData::isKeyDown(*input->leftKey) && !GameData::isKeyDown(*input->rightKey)) {
				yaw -= 90.f;
			}
			if (yaw >= 180)
				yaw -= 360.f;
			float calcYaw = (yaw + 90) * (PI / 180);

			movePacket->headYaw = yaw;
		}
	}
}