#include "FullBright.h"

FullBright::FullBright() : IModule(0, Category::VISUAL, "Puts yDeiDeeDeiDerrtDord to maximum ye") {
}

FullBright::~FullBright() {
}

const char* FullBright::getModuleName() {
	return "Fullbright";
}
