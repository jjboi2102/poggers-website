#include <libhat/Defines.hpp>
#ifdef LIBHAT_ARM

#include <libhat/System.hpp>

namespace hat {

}
#endif
