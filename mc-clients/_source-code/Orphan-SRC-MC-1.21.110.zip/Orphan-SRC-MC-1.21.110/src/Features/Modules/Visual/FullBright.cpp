//
// Created by vastrakai on 9/13/2024.
//

#include "FullBright.hpp"

#include <SDK/Minecraft/ClientInstance.hpp>
#include <SDK/Minecraft/Options.hpp>

void FullBright::onEnable()
{
    // Made a new hook for it to see if I can get it working for Vibrant Visuals sadly NO. :: BaseLightTextureImageBuilderHook
}

void FullBright::onDisable()
{
}

void FullBright::onRenderEvent(RenderEvent& event)
{
}
