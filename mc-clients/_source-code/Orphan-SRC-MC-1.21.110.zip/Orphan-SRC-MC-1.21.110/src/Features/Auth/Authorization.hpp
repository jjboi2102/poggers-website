//
// Created by alteik on 30/10/2024.
//
#pragma once

class Auth
{
public:
    static bool isPrivateUser();
};