//
// Created by vastrakai on 9/22/2024.
//

#pragma once
#include "Event.hpp"

class ClientTickEvent : public Event {
public:
    explicit ClientTickEvent() = default;
};