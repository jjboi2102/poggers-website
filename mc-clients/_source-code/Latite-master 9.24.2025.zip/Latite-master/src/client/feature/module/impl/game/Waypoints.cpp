#include "pch.h"
#include "Waypoints.h"

/*
Waypoints::Waypoints() : Module("Waypoints", "Waypoints", "Shows saved locations.", GAME) {
	
}
*/