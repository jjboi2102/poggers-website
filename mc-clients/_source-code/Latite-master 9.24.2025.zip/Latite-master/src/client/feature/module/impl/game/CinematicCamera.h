#pragma once
#include "../../Module.h"

class CinematicCamera : public Module {
public:
	CinematicCamera();
	void onCinematicCamera(Event& ev);
};

