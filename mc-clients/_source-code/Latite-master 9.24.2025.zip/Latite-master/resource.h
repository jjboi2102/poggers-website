//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by LatiteRewrite.rc

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

#define TEXTFILE 255

#define ICON_LOGO 254
#define ICON_ARROW 253
#define ICON_ARROWBACK 252
#define ICON_CHECKMARK 251
#define ICON_COG 250
#define ICON_HUDEDIT 249
#define ICON_SEARCH 248
#define ICON_X 247
#define ICON_LOGOWHITE 246
#define ICON_DOCUMENT 245

#define JS_LATITEAPI 100

#define LANG_EN_US 101
#define LANG_ES_ES 102
#define LANG_PT_PT 103
#define LANG_ZH_CN 104
#define LANG_ZH_TW 105
#define LANG_AR_AR 106
#define LANG_CS_CZ 107
#define LANG_FR_FR 108
#define LANG_JA_JP 109
#define LANG_PT_BR 110
#define LANG_NL_NL 111
